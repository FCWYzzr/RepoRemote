package pers.fcwy.wordrecite;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;

import pers.fcwy.wordrecite.DataBase.DB;
import pers.fcwy.wordrecite.databinding.MainLayoutBinding;

public class MainMenu extends Activity {

    MainLayoutBinding binding;
    PopupWindow window;
    AtomicReference<String> User;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DB db = new DB(this);
        SharedPreferences sharedPreferences = getSharedPreferences(
                "saved_user", MODE_PRIVATE
        );
        User = new AtomicReference<>(sharedPreferences.getString("last_user", null));
        window = new PopupWindow(this);
        window.setFocusable(true);
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_UNCHANGED);

        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        window.setContentView(View.inflate(this, R.layout.input_popup, null));

        binding = MainLayoutBinding.bind(View.inflate(this, R.layout.main_layout, null));
        binding.floatingActionButton.setOnClickListener(view -> {
            if (window.isShowing())
                window.dismiss();
            else
                window.showAsDropDown(binding.floatingActionButton);
        });
        setContentView(binding.getRoot());
        window.getContentView().findViewById(R.id.confirm).setOnClickListener((view)->{
            if(((EditText) window.getContentView().findViewById(R.id.et)).length() == 0)
                Toast.makeText(this, "please input username", Toast.LENGTH_SHORT).show();
            else{
                User.set(
                        ((EditText) window.getContentView()
                                .findViewById(R.id.et))
                                .getText().toString()
                );
                binding.bEnZh.setEnabled(true);
                binding.bZhEn.setEnabled(true);
                sharedPreferences.edit().putString("last_user", User.get()).apply();
                db.regUser(User.get());
                window.dismiss();
                ((TextView)window.getContentView().findViewById(R.id.tv1)).setText(
                        String.format(Locale.CHINA,
                                "您当前是%s",
                                User)
                );
                ((EditText)window.getContentView().findViewById(R.id.et)).setHint(
                        "更改为其他用户?"
                );
                List<Integer> userData = db.getUserData(User.get());
                int all = 0;
                for (int i :
                        userData)
                    all += i;
                binding.enZh.setText(
                        String.format(Locale.CHINA,
                                "%.2f%%",
                                all * 1. / userData.size())
                );
                ((EditText)window.getContentView().findViewById(R.id.et)).setText("");
            }
        });
        if (Objects.isNull(User.get())){
            binding.bEnZh.setEnabled(false);
            binding.bZhEn.setEnabled(false);
            binding.floatingActionButton.setEnabled(true);
        }
        else {
            ((TextView)window.getContentView().findViewById(R.id.tv1)).setText(
                    String.format(Locale.CHINA,
                            "您当前是%s",
                            User)
            );
            ((EditText)window.getContentView().findViewById(R.id.et)).setHint(
                    "更改为其他用户?"
            );
            List<Integer> userData = db.getUserData(User.get());
            int all = 0;
            for (int i :
                    userData)
                all += i;
            binding.enZh.setText(
                    String.format(Locale.CHINA,
                            "%.2f%%",
                            all * 1. / userData.size())
            );
        }

        binding.bZhEn.setOnClickListener(v->{
            Bundle b = new Bundle();
            b.putString("user", User.get());
            b.putBoolean("ez", false);
            Intent intent = new Intent(this, QuizActivity.class);
            intent.putExtras(b);
            startActivity(intent);
        });

        binding.bEnZh.setOnClickListener(v->{
            Bundle b = new Bundle();
            b.putString("user", User.get());
            b.putBoolean("ez", true);
            Intent intent = new Intent(this, QuizActivity.class);
            intent.putExtras(b);
            startActivity(intent);
        });
    }
}