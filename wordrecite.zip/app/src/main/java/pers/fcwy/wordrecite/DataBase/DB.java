package pers.fcwy.wordrecite.DataBase;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Pair;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import pers.fcwy.wordrecite.R;

public class DB extends SQLiteOpenHelper {
    private final Context context;
    private Integer num;


    public DB(Context context) {
        super(context, "DB", null, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(
                "create table word_recite(id integer primary key AUTOINCREMENT, en varchar(16), zh varchar(16))"
        );
        String[] en = context.getResources().getStringArray(R.array.en),
                zh = context.getResources().getStringArray(R.array.zh);

        for (int i = 0; i < en.length; i++)
            sqLiteDatabase.execSQL(
                    String.format(Locale.CHINA,
                            "insert into word_recite (en, zh) values ( '%s', '%s' )",
                            en[i], zh[i]
                    )
            );

        num = en.length;

    }

    public Integer getNum() {
        return num;
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
    
    public List<Integer>
    getUserData(String User){
        List<Integer> zh = new ArrayList<>(6);
        Cursor cursor = getReadableDatabase().rawQuery(String.format("select * from %s",User), null);
        while(cursor.moveToNext())
            zh.add(cursor.getInt(1));
        System.out.println(zh);
        cursor.close();
        return zh;
    }
    
    public void UpdateUserData(String User, List<Integer> data){
        final SQLiteDatabase writableDatabase = getWritableDatabase();
        for (int i = 0; i < data.size(); i++)
            writableDatabase.execSQL(
                    String.format(Locale.CHINA,
                            "update %s set rate=%d where word_id=%d",
                            User, i, data.get(i))
            );
    }

    public void regUser(String user){
        SQLiteDatabase writableDatabase = getWritableDatabase();
        SQLiteDatabase readableDatabase = getReadableDatabase();
        writableDatabase.execSQL(
                String.format(
                        Locale.CHINA,
                    "create table if not exists %s(word_id integer primary key, rate integer)",
                        user
                )
        );
        Cursor cursor = readableDatabase.rawQuery("select * from word_recite", null);
        while (cursor.moveToNext()){
            writableDatabase.execSQL(String.format(Locale.CHINA,
                    "insert or ignore into %s (word_id, rate) values(%d, %d)",
                    user, cursor.getInt(0), 0
                    ));
        }
        cursor.close();
    }

    public List<Pair<String, String>> getAll(){
        List<Pair<String, String>> ret = new ArrayList<>(6);
        SQLiteDatabase readableDatabase = getReadableDatabase();
        Cursor cursor = readableDatabase.rawQuery("select * from word_recite", null);
        while (cursor.moveToNext())
            ret.add(
                    new Pair<>(cursor.getString(1), cursor.getString(2))
            );

        cursor.close();
        return ret;
    }
}
