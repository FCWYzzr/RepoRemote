package pers.fcwy.wordrecite;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

import pers.fcwy.wordrecite.DataBase.DB;
import pers.fcwy.wordrecite.databinding.ActivityQuizBinding;

public class QuizActivity extends Activity {
    ActivityQuizBinding binding;
    final boolean en_zh = true, zh_en=false;
    boolean mode;
    String User;
    DB db;
    List<Integer> data;
    List<Pair<String, String>> words;
    Random rand;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        rand = new Random();
        db = new DB(this);
        binding = ActivityQuizBinding.bind(View.inflate(
                this, R.layout.activity_quiz, null
        ));
        setContentView(binding.getRoot());
        Bundle b = getIntent().getExtras();
        mode = b.getBoolean("ez");
        User = b.getString("user");
        words = db.getAll();
        data = db.getUserData(User);
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onResume() {
        super.onResume();
        AtomicInteger u = new AtomicInteger(0);
        AtomicInteger d = new AtomicInteger(0);
        for (int i :
                data) {
            u.set(u.get() + i);
            d.set(d.get() + i==0?0:i);
        }
        binding.rateDetail.setText(String.format(
                Locale.CHINA,
                "%.2f",
                u.get()*100./d.get()
        )+'%');
        binding.rateDetail2.setText(String.format(
                Locale.CHINA,
                "%d of %d",
                u.get(), d.get()
        ));
        AtomicInteger choice = new AtomicInteger(rand.nextInt(words.size()));
        binding.questionFace.setText(
                mode == en_zh?words.get(choice.get()).first:words.get(choice.get()).second
        );
        binding.inputWord.setOnEditorActionListener((view,type, eve)->{
            if (type == EditorInfo.IME_ACTION_DONE) {
                if (binding.inputWord.getText().toString().equals(
                        mode==zh_en?words.get(choice.get()).first:words.get(choice.get()).second
                )){
                    Toast.makeText(this, "正确", Toast.LENGTH_SHORT).show();
                    data.set(choice.get(), data.get(choice.get()) + 1);
                }
                else{
                    System.out.println(binding.inputWord);
                    System.out.println(mode==zh_en?words.get(choice.get()).first:words.get(choice.get()).second);
                    Toast.makeText(this, "错误", Toast.LENGTH_SHORT).show();
                    data.set(choice.get(), data.get(choice.get()) - 1);
                }
                d.incrementAndGet();
                binding.rateDetail.setText(String.format(
                        Locale.CHINA,
                        "%.2f %%",
                        u.get()*1./d.get()
                ));
                binding.rateDetail2.setText(String.format(
                        Locale.CHINA,
                        "%d of %d",
                        u.get(), d.get()
                ));
                choice.set(rand.nextInt(words.size()));
                binding.questionFace.setText(
                        mode == en_zh?words.get(choice.get()).first:words.get(choice.get()).second
                );
                binding.inputWord.getText().clear();
            }


            return true;
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        db.UpdateUserData(User, data);
    }

    
}