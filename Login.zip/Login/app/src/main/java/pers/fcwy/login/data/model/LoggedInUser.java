package pers.fcwy.login.data.model;

import androidx.annotation.NonNull;

import java.util.Locale;
import java.util.Objects;

/**
 * Data class that captures user information for logged in users retrieved from LoginRepository
 */
public class LoggedInUser {

    private final String password;
    private final String displayName;

    public LoggedInUser(String displayName, String password) {
        this.password = password;
        this.displayName = displayName;
    }

    public boolean checkPassword(String password) {
        return password.equals(this.password);
    }

    public String getDisplayName() {
        return displayName;
    }

    @NonNull
    @Override
    public String toString() {
        return String.format(Locale.CHINA,
                "{ displayName : '%s', password: '%s'}",
                displayName, password);
    }

    public static LoggedInUser parse(@NonNull String Json){
        if (Json.length() == 0 || Json.equals("{}"))
            return EMPTY;
        int i1, i2;
        i1 = Json.indexOf('\'');
        i2 = Json.indexOf('\'',i1+1);
        String name = Json.substring(i1, i2);

        i1 = Json.indexOf('\'', i2+1);
        i2 = Json.indexOf('\'',i1+1);
        String password = Json.substring(i1, i2);

        return new LoggedInUser(name, password);
    }

    final public static LoggedInUser EMPTY =
            new LoggedInUser("", "");

    public boolean empty() {
        return this.equals(EMPTY);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LoggedInUser user = (LoggedInUser) o;
        return Objects.equals(password, user.password) && Objects.equals(displayName, user.displayName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(password, displayName);
    }
}