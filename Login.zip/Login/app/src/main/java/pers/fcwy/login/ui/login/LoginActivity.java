package  pers.fcwy.login.ui.login;

import androidx.lifecycle.ViewModelProvider;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import pers.fcwy.login.R;
import pers.fcwy.login.data.model.LoggedInUser;
import pers.fcwy.login.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;
    private Set<LoggedInUser> Users;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

         binding = ActivityLoginBinding.inflate(getLayoutInflater());
         setContentView(binding.getRoot());

         Users = new HashSet<>();

        final EditText usernameEditText = binding.username;
        final EditText passwordEditText = binding.password;
        final Button loginButton = binding.login;

        Set<String> s =
                getSharedPreferences("saved", MODE_PRIVATE)
                        .getAll().keySet();
        for(String name: s){
            Users.add(
                    new LoggedInUser(
                            name,
                            getSharedPreferences("saved", MODE_PRIVATE)
                                    .getString(name, "000000")
                    )
            );
        }

        LoggedInUser user = LoggedInUser.parse(
                getSharedPreferences("temp", MODE_PRIVATE)
                        .getString("LIU", "")
        );
        usernameEditText.setText(user.getDisplayName());

        loginButton.setOnClickListener(
                btn-> {
                    if (! user.empty() &&
                            user.getDisplayName()
                                    .equals(
                                            usernameEditText
                                                    .getText()
                                                    .toString()
                                    )
                    ){
                        if(user.checkPassword(passwordEditText.getText().toString()))
                            Toast.makeText(this, "Login success", Toast.LENGTH_SHORT).show();
                        else
                            Toast.makeText(this, "wrong password", Toast.LENGTH_SHORT).show();
                    }

                    getSharedPreferences("saved", MODE_PRIVATE)
                            .edit()
                            .putString(
                                    usernameEditText.getText().toString(),
                                    passwordEditText.getText().toString()
                            )
                            .apply();
                    getSharedPreferences("temp", MODE_PRIVATE)
                            .edit()
                            .putString(
                                    "LIU",
                                    new LoggedInUser(
                                            usernameEditText.getText().toString(),
                                            passwordEditText.getText().toString()
                                    ).toString()
                            )
                            .apply();
                    Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
                }

        );




    }

}