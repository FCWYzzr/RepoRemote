package pers.fcwy.flowerstore;

import org.junit.Test;

import static org.junit.Assert.*;

import pers.fcwy.flowerstore.model.Data;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(new Integer(23),
                Data.parse("[1, 23, 4]").get_order().get(1));
    }
}