package pers.fcwy.flowerstore.model;

import android.app.Activity;
import android.graphics.Rect;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewbinding.ViewBinding;

public abstract class FcwyActivity <bind extends ViewBinding> extends AppCompatActivity {
    protected bind binding;
    abstract protected void initialView();
    abstract protected void fitScreenImpl(int width, int height);
    abstract protected void bindControllers();

    protected final void fitScreen(){
        Rect bounds = getWindowManager().getCurrentWindowMetrics().getBounds();
        fitScreenImpl(bounds.width(), bounds.height());
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initialView();
        fitScreen();
        bindControllers();

    }
}
