package pers.fcwy.flowerstore.model;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public class Data{
    private final List<Integer> _order;
    public Data(List<Integer> order){
        _order = new ArrayList<>(order);
    }
    private Data(ArrayList<Integer> order){
        _order = order;
    }

    public String Json(){
        StringBuilder SB = new StringBuilder();
        SB.append('[');
        for (Integer i :
                _order)
            SB.append(", ").append(i);
        SB.replace(0, 3, "[");
        return SB.append(']').toString();
    }

    public static Data parse(String json){
        Reader reader = new StringReader(json);
        StringBuilder stringBuilder = new StringBuilder();
        ArrayList<Integer> order = new ArrayList<>(6);
        try {
            char ch;
            //noinspection ResultOfMethodCallIgnored
            reader.read();
            while ((ch = (char)reader.read())  != (char)-1){
                if (Character.isDigit(ch)){
                    stringBuilder.append(ch);
                }
                else{
                    //noinspection ResultOfMethodCallIgnored
                    reader.read();
                    order.add(Integer.parseInt(stringBuilder.toString()));
                    stringBuilder.delete(0, stringBuilder.length());
                }
            }
        } catch (IOException ignored) {}
        return new Data(order);
    }

    public List<Integer> get_order() {
        return _order;
    }
}
