package pers.fcwy.flowerstore.ChoiceActivity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DB extends SQLiteOpenHelper {

    private final static String Name = "FSDB";
    private final static int version = 1;

    public DB(@Nullable Context context) {
        super(context, Name, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sql = "create table " +
                "orders(" +
                "id integer primary key autoincrement," +
                "detail varchar(64))";
        sqLiteDatabase.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
