package pers.fcwy.flowerstore.model;

public interface NoParamFunction {
    void runnable();
}
