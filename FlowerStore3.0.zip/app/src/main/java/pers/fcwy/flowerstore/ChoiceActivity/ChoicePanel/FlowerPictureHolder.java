package pers.fcwy.flowerstore.ChoiceActivity.ChoicePanel;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FlowerPictureHolder extends RecyclerView.ViewHolder {
    public FlowerPictureHolder(@NonNull View itemView) {
        super(itemView);
    }


    public ImageView getItemView(){
        return (ImageView) itemView;
    }

    public void setImage(Drawable drawable) {
        getItemView().setImageDrawable(drawable);
    }

    public void highlight(){
        getItemView().setImageAlpha(192);
    }

    public void de_highlight(){
        getItemView().setImageAlpha(255);
    }
}
