package pers.fcwy.flowerstore.ChoiceActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

import pers.fcwy.flowerstore.ChoiceActivity.ChoicePanel.ChoiceAdapter;
import pers.fcwy.flowerstore.R;
import pers.fcwy.flowerstore.databinding.LayoutChoiceBinding;
import pers.fcwy.flowerstore.model.Data;
import pers.fcwy.flowerstore.model.FcwyActivity;
import pers.fcwy.flowerstore.model.OneParamFunction;
import pers.fcwy.flowerstore.model.TwoParamsFunction;

@SuppressWarnings("RedundantStringFormatCall")
public class ChoiceActivity extends FcwyActivity<LayoutChoiceBinding> {

    private List<Integer> order;
    private List<Integer> cost;
    private Thread t;

    private int lastPos = 0;

    @Override
    protected void initialView() {
        binding = LayoutChoiceBinding.inflate(getLayoutInflater());
        View rootView = binding.getRoot();
        setContentView(rootView);
    }

    @Override
    protected void fitScreenImpl(int width, int height) {

        if (Objects.isNull(binding.menu.getLayoutParams())){
            binding.menu.setLayoutParams(
                    new RecyclerView.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            height - 50
                    )
            );
        }
        else{
            ViewGroup.LayoutParams vglp = binding.menu.getLayoutParams();
            vglp.width = ViewGroup.LayoutParams.MATCH_PARENT;
            vglp.height = height;
        }

        if (Objects.isNull(binding.panel.getLayoutParams())){
            binding.panel.setLayoutParams(
                    new RecyclerView.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            0
                    )
            );
        }
        else{
            ViewGroup.LayoutParams vglp = binding.panel.getLayoutParams();
            vglp.width = ViewGroup.LayoutParams.MATCH_PARENT;
            vglp.height = 0;
        }
    }

    @SuppressLint("DefaultLocale")
    @Override
    protected void bindControllers() {

        AtomicBoolean changed = new AtomicBoolean(false);

        binding.panel.setEnabled(false);
        binding.menu.setEnabled(true);

        order = Arrays.asList(0,0,0,0,0,0);
        cost = Arrays.asList(1,2,3,4,5,6);



        List<Drawable> element = new ArrayList<>(6);
        int[] ele = new int[]{
                R.drawable._1,
                R.drawable._2,
                R.drawable._3,
                R.drawable._4,
                R.drawable._5,
                R.drawable._6
        };

        for (int res: ele)
            element.add(AppCompatResources.getDrawable(this, res));


        System.out.println(
                String.format("done, read %d files", element.size())
        );


        ChoiceAdapter choiceAdapter = new ChoiceAdapter(
                element, showPanel, hidePanel, updatePanel, binding.menu
        );

        binding.menu.setLayoutManager(new GridLayoutManager(this, 3));
        binding.menu.setAdapter(choiceAdapter);

        binding.buttonAdd.setOnClickListener(
                view -> {
                    changed.set(true);
                    int ori = Integer.parseInt(binding.number.getText().toString());
                    binding.number.setText(
                            String.format(Locale.CHINA, "%d", ori+1)
                    );
                    binding.Cost.setText(
                            String.format(Locale.CHINA,
                                    "%d",
                                    cost.get(lastPos) * (ori + 1))
                    );
                }

        );

        binding.buttonMinus.setOnClickListener(
                view -> {
                    changed.set(true);
                    int ori = Integer.parseInt(binding.number.getText().toString());
                    binding.number.setText(
                            String.format(Locale.CHINA,
                                    "%d",
                                    ori == 0?ori:ori-1)
                    );
                    binding.Cost.setText(
                            String.format(Locale.CHINA,
                                    "%d",
                                    ori == 0?0:(ori - 1) * cost.get(lastPos))
                    );
                }

        );
        binding.buy.setOnClickListener(view -> {
            changed.set(true);
            hidePanel.runnable(lastPos);
            StringBuilder sb = new StringBuilder("您共订购:\n");
            int tot = 0;
            for(int i=0;i<6;i++) {
                sb.append(String.format(Locale.CHINA, "Flower No.%d * %d = %d\n",
                        i, order.get(i), cost.get(i) * order.get(i)));
                tot += cost.get(i) * order.get(i);
                order.set(i, 0);
            }
            sb.append(String.format(Locale.CHINA, "total: %d\n",
                    tot));
            new AlertDialog.Builder(this)
                    .setTitle("购买成功")
                    .setMessage(sb.toString())
                    .create().show();
        });

        binding.progressBar.setMax(1000);
        AtomicBoolean started = new AtomicBoolean(true);

        Handler handler = new Handler(Looper.myLooper()){
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                if(msg.what == 1)
                    Toast.makeText(ChoiceActivity.this,
                            "please do something", Toast.LENGTH_SHORT).show();
            }
        };

        DB db = new DB(this);

        findViewById(R.id.save).setOnClickListener(
                btn-> {
                    SQLiteDatabase sqldb =
                    db
                            .getWritableDatabase();
                    sqldb.execSQL(
                                    String
                                            .format(
                                                    Locale.CHINA,
                                                    "insert into orders (detail) values ('%s')",
                                                    new Data(order).Json()));
                    sqldb.close();
                    Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
                }
        );
        findViewById(R.id.load).setOnClickListener(
                btn->{
                    SQLiteDatabase sqldb = db.getReadableDatabase();
                    Cursor cursor = sqldb.query("orders", new String[] { "id",
                            "detail" }, null, null, null, null, "id");
                    cursor.moveToLast();
                    order = Data.parse(cursor.getString(1)).get_order();
                    Toast.makeText(this, "loaded", Toast.LENGTH_SHORT).show();
                }
        );

        t = new Thread(()->{
            while(true) {
                if (started.get())
                    while (true) {
                        if (changed.get()) {
                            binding.progressBar.setProgress(0);
                            changed.set(false);
                        }
                        else if (binding.progressBar.getProgress() < binding.progressBar.getMax()) {
                            try {
                                //noinspection BusyWait
                                Thread.sleep(30);
                                binding.progressBar.incrementProgressBy(1);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                                break;
                            }
                        }
                        else{
                            started.set(false);
                            handler.sendEmptyMessage(1);
                        }
                    }
                else{
                    started.set(changed.get());
                }

            }
        });
        t.setDaemon(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {t.join(50);}
        catch (InterruptedException ignored) {}
    }

    final private OneParamFunction showPanel = (pos)->{
        ViewGroup.LayoutParams vglp1 = binding.menu.getLayoutParams(),
            vglp2 = binding.panel.getLayoutParams();
        vglp1.height -= 1000;
        vglp2.height =1000;
        binding.menu.setLayoutParams(vglp1);
        binding.panel.setLayoutParams(vglp2);
        binding.buy.setEnabled(true);
        binding.buttonAdd.setEnabled(true);
        binding.buttonMinus.setEnabled(true);
        binding.number.setText(
                String.format(Locale.CHINA,"%d",order.get(pos)));
        binding.Cost.setText(
                String.format(Locale.CHINA,"%d",order.get(pos) * cost.get(pos))
        );
        lastPos = pos;
    };

    final private OneParamFunction hidePanel = (pos)->{
        ViewGroup.LayoutParams vglp1 = binding.menu.getLayoutParams(),
                vglp2 = binding.panel.getLayoutParams();
        vglp1.height += 1000;
        vglp2.height = 0;
        binding.menu.setLayoutParams(vglp1);
        binding.panel.setLayoutParams(vglp2);
        binding.panel.setEnabled(false);
        binding.buy.setEnabled(false);
        binding.buttonMinus.setEnabled(false);
        order.set(pos, Integer.parseInt(binding.number.getText().toString()));
        lastPos = 0;
    };

    final private TwoParamsFunction updatePanel = (pos1, pos2)->{
        order.set(pos1, Integer.parseInt(binding.number.getText().toString()));
        binding.number.setText(String.format(Locale.CHINA,"%d",order.get(pos2)));
        binding.Cost.setText(
                String.format(Locale.CHINA,"%d",order.get(pos2) * cost.get(pos2))
        );
        lastPos = pos2;
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_layout, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.check) {
            item.getSubMenu().clear();
            for(int i=0;i<6;i++)
                item
                   .getSubMenu()
                   .add(String.format(Locale.CHINA,
                           "No.%d  %d", i, order.get(i)));

        }
        else if (itemId == R.id.buy) {
            int c = 0;
            for(int i=0;i<6;i++)
                c += order.get(i) * cost.get(i);
            Toast.makeText(this,
                    String.format(Locale.CHINA,
                            "Total: %d", c),
                    Toast.LENGTH_SHORT
            ).show();
        }
        return super.onOptionsItemSelected(item);
    }
}