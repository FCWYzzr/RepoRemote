package pers.fcwy.flowerstore.model;

public interface OneParamFunction {
    void runnable(int viewPos);
}
