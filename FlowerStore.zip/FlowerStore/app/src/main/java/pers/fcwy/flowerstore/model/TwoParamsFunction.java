package pers.fcwy.flowerstore.model;

public interface TwoParamsFunction {
    void runnable(int pos1, int pos2);
}
