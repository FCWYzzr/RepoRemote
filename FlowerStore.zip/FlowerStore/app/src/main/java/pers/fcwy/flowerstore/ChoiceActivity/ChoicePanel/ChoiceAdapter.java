package pers.fcwy.flowerstore.ChoiceActivity.ChoicePanel;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Objects;

import pers.fcwy.flowerstore.R;
import pers.fcwy.flowerstore.model.NoParamFunction;
import pers.fcwy.flowerstore.model.OneParamFunction;
import pers.fcwy.flowerstore.model.TwoParamsFunction;

public class ChoiceAdapter extends RecyclerView.Adapter<FlowerPictureHolder> {

    private final List<Drawable> element;
    int selected;
    OneParamFunction show, hide;
    TwoParamsFunction update;
    final RecyclerView master;

    public ChoiceAdapter(List<Drawable> ld, OneParamFunction s, OneParamFunction h, TwoParamsFunction u, RecyclerView master) {
        super();
        element = ld;
        selected = -1;
        show = s;
        hide = h;
        update = u;
        this.master = master;
    }

    @NonNull
    @Override
    public FlowerPictureHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new FlowerPictureHolder(
                View.inflate(parent.getContext(), R.layout.layout_list_item, null)
        );
    }

    @Override
    public void onBindViewHolder(@NonNull FlowerPictureHolder holder, int position) {
        holder.setImage(element.get(position));
        holder.getItemView().setOnClickListener(view->{
            if (selected == holder.getAdapterPosition()) {
                holder.de_highlight();
                hide.runnable(selected);
                notifyItemChanged(holder.getAdapterPosition());
                selected = -1;

            }
            else if (selected != -1){
                ((FlowerPictureHolder) Objects.requireNonNull(master.findViewHolderForAdapterPosition(selected)))
                        .de_highlight();
                notifyItemChanged(selected);
                holder.highlight();
                update.runnable(selected, holder.getAdapterPosition());
                selected = holder.getAdapterPosition();
            }
            else{
                holder.highlight();
                selected = holder.getAdapterPosition();
                show.runnable(holder.getAdapterPosition());
            }
        });
        holder.de_highlight();
    }

    @Override
    public int getItemCount() {
        return element.size();
    }
}
