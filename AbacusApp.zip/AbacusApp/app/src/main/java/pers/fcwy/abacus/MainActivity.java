package pers.fcwy.abacus;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.TextView;

import java.util.Locale;

import pers.fcwy.abacus.Logic.AbacusLogic;
import pers.fcwy.abacus.ViewLogic.Action;

/*
                R.id.l41_b1, R.id.l41_b2, R.id.l41_b3, R.id.l41_b4,
                R.id.l42_b1, R.id.l42_b2, R.id.l42_b3, R.id.l42_b4,
                R.id.l43_b1, R.id.l43_b2, R.id.l43_b3, R.id.l43_b4,
                R.id.l44_b1, R.id.l44_b2, R.id.l44_b3, R.id.l44_b4,
                R.id.l45_b1, R.id.l45_b2, R.id.l45_b3, R.id.l45_b4,
                R.id.l46_b1, R.id.l46_b2, R.id.l46_b3, R.id.l46_b4
 */


public class MainActivity extends Activity {

    TextView His, Screen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final int[] numbers = new int[]{
                        R.id.l43_b1, R.id.l43_b2, R.id.l43_b3,
                        R.id.l44_b1, R.id.l44_b2, R.id.l44_b3,
                        R.id.l45_b1, R.id.l45_b2, R.id.l45_b3,
                        R.id.l46_b2, R.id.l46_b3
                };

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        PopupWindow function = new PopupWindow(this);
        function.setContentView(
                View.inflate(
                        this,
                        R.layout.popup,
                        null)
        );

        Screen = findViewById(R.id.Screen);
        TextView Mem = findViewById(R.id.l1_tv1);
        His = findViewById(R.id.l1_tv2);

        for (int id: numbers)
            findViewById(id).setOnClickListener(
                    Action.onClickInputButton(Screen, getString(R.string.InvalidFormula), His)
            );
        // MC
        setOnClick(R.id.l41_b1, btn->
            Mem.setText("0")
        );
        // M+
        setOnClick(R.id.l41_b2, btn->{
            findViewById(R.id.l45_b4).performClick();

            if(!Screen.getText().equals(getString(R.string.InvalidFormula))){
                Double res = AbacusLogic.eval(String.format(Locale.CHINA,
                        "%s+%s", Screen.getText(), Mem.getText()));
                Mem.setText(String.format(Locale.CHINA,
                        "%.0f", res));
            }

        });
        // M-
        setOnClick(R.id.l41_b3, btn->{
            findViewById(R.id.l45_b4).performClick();

            if(!Screen.getText().equals(getString(R.string.InvalidFormula))){
                Double res = AbacusLogic.eval(String.format(Locale.CHINA,
                        "%s-%s", Mem.getText(), Screen.getText()));
                Mem.setText(String.format(Locale.CHINA,
                        "%.0f", res));
            }

        });
        // MR
        setOnClick(R.id.l41_b4, btn->
                Mem.setText("0"));
        //C
        setOnClick(R.id.l42_b1, btn->
            Screen.setText(""));
        // div
        setOnClick(R.id.l42_b2, btn->
                Screen.setText(
                        String.format(
                                Locale.CHINA,
                                "%s%c", Screen.getText(),
                                '/'
                        )
                ));
        // multi
        setOnClick(R.id.l42_b3, btn->
                Screen.setText(
                        String.format(
                                Locale.CHINA,
                                "%s%c", Screen.getText(),
                                '*'
                        )
                ));
        // del button
        setOnClick(R.id.l42_b4, (btn)->{
            if (Screen.length() == 0)
                return;
            if(Screen.length() == 1 || Screen.getText().equals(getString(R.string.InvalidFormula))) {
                Screen.setText("");
                return;
            }
            StringBuilder sb = new StringBuilder(Screen.getText());
            sb.deleteCharAt(sb.length()-1);
            Screen.setText(String.format(Locale.CHINA,
                    "%s", sb
            ));
        });
        // subtract
        setOnClick(R.id.l43_b4, btn->
                Screen.setText(
                        String.format(
                                Locale.CHINA,
                                "%s%c", Screen.getText(),
                                '-'
                        )
                ));
        // add
        setOnClick(R.id.l44_b4, btn->
                Screen.setText(
                        String.format(
                                Locale.CHINA,
                                "%s%c", Screen.getText(),
                                '+'
                        )
                ));
        // percent
        setOnClick(R.id.l46_b1, btn->
                Screen.setText(
                        String.format(
                                Locale.CHINA,
                                "%s%s", Screen.getText(),
                                "/100"
                        )
                ));

        // equal button
        setOnClick(R.id.l45_b4,(btn)->{
            His.setText(R.string.no_his);
            if (Screen.getText().equals(getString(R.string.InvalidFormula))) {
                Screen.setText("");
                return;
            }
            Double d = AbacusLogic.eval(Screen.getText().toString());
            if(d.equals(Double.NaN))
                Screen.setText(R.string.InvalidFormula);
            else if(d - d.intValue() < 1e-5)
                Screen.setText(String.format(Locale.CHINA,
                    "%.0f", d));
            else
                Screen.setText(String.format(Locale.CHINA,
                        "%f", d));
        });
        popupWindow popupWindow = new popupWindow(this, Screen);
        setOnClick(R.id.l46_b4, btn->{
            if(popupWindow.isShowing())
                popupWindow.dismiss();
            else
                popupWindow.showAsDropDown(Screen);
        });

    }

    private void setOnClick(int id, Button.OnClickListener listener){
        findViewById(id).setOnClickListener(btn->{
            if (Screen.getText().equals(getString(R.string.InvalidFormula)))
                Screen.setText("");
            listener.onClick(btn);
        });
    }
}