package pers.fcwy.abacus.Logic;

import java.io.StringReader;
import java.util.Locale;
import java.util.Vector;

import AbacusAPI.AbacusCore.Syntax.Token.Element;
import AbacusAPI.AbacusCore.Syntax.Token.TokenArray;
import AbacusAPI.AbacusCore.Syntax.Tree.ASTBuilder;
import AbacusAPI.AbacusCore.Syntax.Tree.ASTInterpreter;
import AbacusAPI.AbacusCore.Syntax.Tree.TreeElement.SyntaxTreeFork;
import InTimeCore.InTimeAVM;


public class AbacusLogic {
    public static void init(){
        InTimeAVM.initialize();
    }

    public static Double eval(String Formula){
        try {
            Vector<Element> elements = TokenArray.Read(new StringReader(
                    Formula
            ));
            SyntaxTreeFork syntaxTreeRoot = ASTBuilder.BuildFromTokens(elements);
            Object eval = ASTInterpreter.eval(syntaxTreeRoot.kids().get(0));
            return ((Number) eval).doubleValue();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Double.NaN;
    }
}
