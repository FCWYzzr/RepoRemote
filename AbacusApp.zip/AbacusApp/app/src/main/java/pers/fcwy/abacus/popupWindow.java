package pers.fcwy.abacus;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class popupWindow extends PopupWindow {
    public popupWindow(Context context, TextView screen) {
        super(context);
        setContentView(View.inflate(context, R.layout.popup, null));
        setOnClick(R.id.pl1_b1, btn-> screen.setText(
                String.format(Locale.CHINA,
                        "%s%s", screen.getText(),
                        ((Button)btn).getText())
        ));
        setOnClick(R.id.pl1_b2, btn-> screen.setText(
                String.format(Locale.CHINA,
                        "%s%s", screen.getText(),
                        ((Button)btn).getText())
        ));
        setOnClick(R.id.pl1_b3, btn-> screen.setText(
                String.format(Locale.CHINA,
                        "1 / (%s)", screen.getText())
        ));
        setOnClick(R.id.pl2_b1, btn-> screen.setText(
                String.format(Locale.CHINA,
                        "power(%s, 2)", screen.getText())
        ));
        setOnClick(R.id.pl2_b2, btn-> screen.setText(
                String.format(Locale.CHINA,
                        "power(%s, 3)", screen.getText())
        ));
        setOnClick(R.id.pl2_b3, btn-> screen.setText(
                String.format(Locale.CHINA,
                        "power(%s, ", screen.getText())
        ));
        setOnClick(R.id.pl3_b1, btn-> screen.setText(
                String.format(Locale.CHINA,
                        "round(%s)", screen.getText())
        ));
        setOnClick(R.id.pl3_b2, btn-> screen.setText(
                String.format(Locale.CHINA,
                        "sqrt(%s)", screen.getText())
        ));
        setOnClick(R.id.pl3_b3, btn-> screen.setText(
                String.format(Locale.CHINA,
                        "power(%s, -", screen.getText())
        ));
        setOnClick(R.id.pl4_b1, btn-> screen.setText(
                String.format(Locale.CHINA,
                        "%s2.71828", screen.getText())
        ));
        setOnClick(R.id.pl4_b2, btn-> screen.setText(
                String.format(Locale.CHINA,
                        "abs(%s)", screen.getText())
        ));
        setOnClick(R.id.pl4_b3, btn->
                Toast.makeText(context,
                        "本计算器内核为算盘语言虚拟机（AVM），其功能远不止如此..."
                        , Toast.LENGTH_SHORT).show()
        );
        getContentView().findViewById(R.id.pl4_b3).setOnLongClickListener(btn->{
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/FCWYzzr/Abacus"));
            context.startActivity(intent);
            return false;
        });
    }
    private void setOnClick(int id, Button.OnClickListener listener){
        getContentView().findViewById(id).setOnClickListener(listener);
    }
}
