package pers.fcwy.abacus.ViewLogic;

import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;

import pers.fcwy.abacus.Logic.AbacusLogic;
import pers.fcwy.abacus.R;

public final class Action {
    public static Button.OnClickListener onClickInputButton(TextView screen, String IF, TextView His){
        if (screen.getText().equals(IF))
            screen.setText("");
        return btn-> {
            screen.setText(
                    String.format(Locale.CHINA,
                            "%s%s",
                            screen.getText(), ((Button) btn).getText())
            );
            His.setText(
                    String.format(Locale.CHINA,
                            "%.2f",
                            AbacusLogic.eval((String) screen.getText()))
            );
        };
    }

}
